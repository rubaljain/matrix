# Matrix
A python utility to traverse through the directory for checking the files with 777 permissions and the stored PII information in all the files.

## Usage

python matrix.py -d <directory_path>

Note: If argument (-d) directory path is not provided, it scans the current directory.

## Install as Python Package

1. Clone & navigate into the repository
2. Run "sudo python setup.py install"
3. Run "matrix" command from any location. "-d" argument can be provided to scan any specific directory
